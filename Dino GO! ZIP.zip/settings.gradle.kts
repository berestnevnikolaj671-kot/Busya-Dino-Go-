rootProject.name = "BusyaDinoGO_"
include(":app")